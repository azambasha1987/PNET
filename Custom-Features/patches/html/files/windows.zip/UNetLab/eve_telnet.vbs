' ============================================================
' PNetLab & EVE-NG SecureCRT Telnet Integration Wrapper
' Automatically docks sessions into named SecureCRT tabs (/T /N "<Session>")
' Supports telnet://<host>:<port>#<device_name> and telnet://<host>:<port>
' ============================================================
Set WshShell = CreateObject("WScript.Shell")
Set args = WScript.Arguments

Function DecodeURL(sText)
    Dim i, char, decoded
    decoded = ""
    i = 1
    Do While i <= Len(sText)
        char = Mid(sText, i, 1)
        If char = "+" Then
            decoded = decoded & " "
            i = i + 1
        ElseIf char = "%" And i + 2 <= Len(sText) Then
            On Error Resume Next
            decoded = decoded & Chr("&H" & Mid(sText, i + 1, 2))
            If Err.Number <> 0 Then
                decoded = decoded & Mid(sText, i, 3)
                Err.Clear
            End If
            On Error GoTo 0
            i = i + 3
        Else
            decoded = decoded & char
            i = i + 1
        End If
    Loop
    DecodeURL = decoded
End Function

If args.Count > 0 Then
    raw = args(0)
    raw = Replace(raw, Chr(34), "")
    raw = Replace(raw, "telnet://", "")
    raw = Replace(raw, "telnet:", "")
    raw = Replace(raw, "/", "")
    raw = Trim(raw)

    sessionTitle = ""
    If InStr(raw, "#") > 0 Then
        hashParts = Split(raw, "#")
        raw = hashParts(0)
        sessionTitle = DecodeURL(hashParts(1))
    End If

    parts = Split(raw, ":")
    If UBound(parts) >= 1 Then
        host = parts(0)
        port = parts(1)

        If Trim(sessionTitle) = "" Then
            sessionTitle = host & ":" & port
        End If

        Set fso = CreateObject("Scripting.FileSystemObject")
        scrtPath = ""
        candidates = Array(_
            "C:\Program Files\VanDyke Software\SecureCRT.exe",_
            "C:\Program Files\VanDyke Software\SecureCRT\SecureCRT.exe",_
            "C:\Program Files (x86)\VanDyke Software\SecureCRT.exe",_
            "C:\Program Files (x86)\VanDyke Software\SecureCRT\SecureCRT.exe"_
        )
        For Each c In candidates
            If fso.FileExists(c) Then
                scrtPath = c
                Exit For
            End If
        Next
        If scrtPath = "" Then scrtPath = "C:\Program Files\VanDyke Software\SecureCRT.exe"

        cmd = Chr(34) & scrtPath & Chr(34) & " /T /N " & Chr(34) & sessionTitle & Chr(34) & " /TELNET " & host & " " & port
        WshShell.Run cmd, 1, False
    End If
End If
